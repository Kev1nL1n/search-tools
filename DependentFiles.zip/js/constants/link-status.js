module.exports = {
    WAIT: 0,
    SEARCHING: 1,
    ERROR: 2,
    SKIP: 3,
    DONE: 9
}
