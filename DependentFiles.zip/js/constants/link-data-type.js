module.exports = {
    PHONE: 0,
    TEL: 1,
    EMAIL: 2,
    FILE: 3
}
